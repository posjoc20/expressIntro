import {ITodo} from "../../model/ITodo";

window.onload = () => {
    fetch('./todos')
        .then(response => response.json())
        .then(data => {
            const todos:ITodo[] = data as ITodo[];
            let table = document.getElementById("tableBody");

            todos.forEach(t => {
                let e = document.createElement("tr");
                let header = document.createElement("td");
                let description = document.createElement("td");

                header.innerText = t.name;
                description.innerText = t.description;
                e.append(header);
                e.append(description);

                // @ts-ignore
                table.append(e);
            });
        });
}

