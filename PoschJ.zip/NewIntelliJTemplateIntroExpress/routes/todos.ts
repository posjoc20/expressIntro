import express, {Request, Response} from "express";
import {ITodo} from "../model/ITodo"; //request & response are types, that enable autocompletion

let router = express.Router();

router.get('/', (req:Request, res:Response) => {
   res.send(todos);
});

module.exports = router;

let todos:ITodo[] = [
   {
      name:"test", description:"lorem ipsum..."
   },
   {
      name:"have fun", description:"enjoy my holidays"
   }
]